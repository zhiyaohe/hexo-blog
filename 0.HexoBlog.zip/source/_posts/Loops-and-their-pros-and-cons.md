---
title: Loops and their pros and cons
tags:
  - Java
  - CS1102
  - CS1102 Discussion Assignment
  - Private
categories: Java
description: "CS1102 discussion assignment unit 2. Here's something encrypted, password is required to continue reading."
theme: up
password: 'Private@UoPeople'
date: 2022-01-09 10:27:47
---
## Questions
Give an example of a while loop, then provide the equivalent do-while loop and for loop. Then give a different example of a do-while loop, along with the equivalent while loop and for loop. Finally, give an example of a for loop, along with the equivalent while loop and do-while loop. Use your examples to illustrate the advantages and disadvantages of each looping structure, and describe those advantages and disadvantages.
<!--more-->

## 1. Examples
### 1.1. Examples for a  while  loop, the equivalent do-while  loop and  for  loop
#### 1.1.1 A while loop
Codes:
``` java
package discussion_assignment_1;

/**
 * Calculate the product of positive integers 1 to 10
 */
public class WhileLoop {
    public static void main(String[] args) {
        //Initialization
        int product = 1;
        int i = 1;

        // The while loop
        while (i < 11) {
            product *= i;
            i++;
        }

        System.out.printf("The product of positive integers 1 to 10 is: %d ", product);
    }
}
```
Outputs:
``` java
The product of positive integers 1 to 10 is: 3628800
```
#### 1.1.2 The equivalent do-while loop
Codes:
``` java
package discussion_assignment_1;

/**
 * Calculate the product of positive integers 1 to 10
 */
public class DoWhileLoop {
    public static void main(String[] args) {
        //Initialization
        int product = 1;
        int i = 1;

        //The equivalent do-while loop
        do {
            product *= i;
            i++;
        } while (i < 11);

        System.out.printf("The product of positive integers 1 to 10 is: %d ", product);
    }
}
```
Outputs:
``` java
The product of positive integers 1 to 10 is: 3628800
```
#### 1.1.3 The equivalent for loop
Codes:
``` java
package discussion_assignment_1;

/**
 * Calculate the product of positive integers 1 to 10
 */
public class ForLoop {
    public static void main(String[] args) {
        //Initialization
        int product = 1;

        //The equivalent for loop
        for (int i = 1; i < 11; i ++){
            product *= i;
        }

        System.out.printf("The product of positive integers 1 to 10 is: %d ", product);
    }
}
```
Outputs:
``` java
The product of positive integers 1 to 10 is: 3628800
```

### 1.2. Examples for a do-while loop, the equivalent while loop and for loop
#### 1.2.1. A do-while loop
Codes:
``` java
package discussion_assignment_2;

import java.util.Scanner;

/**
 * Try on clothes some times before we deciding on buying it.
 */

public class DoWhileLoop {
    public static void main(String[] args) {
        // initialization
        int times = 0;
        boolean tryAagin = false;

        //do-while loop
        do {
            times++;
            System.out.println("The number of times you tried on clothes:" + times);
            System.out.print("Do you want to try on your clothes again? please input true or false: ");
            tryAagin = new Scanner(System.in).nextBoolean();
        } while (tryAagin == true);
    }
}
```
Outputs:
``` java
The number of times you tried on clothes:1
Do you want to try on your clothes again? please input true or false: true
The number of times you tried on clothes:2
Do you want to try on your clothes again? please input true or false: false
```
#### 1.2.2. The equivalent while loop:
Codes:
``` java
package discussion_assignment_2;

import java.util.Scanner;

/**
 * Try on clothes some times before we deciding on buying it.
 */
public class WhileLoop {
    public static void main(String[] args) {
        // initialization
        int times = 0;
        boolean tryAagin = false;

        //Trying on clothes for the first time
        times++;
        System.out.println("The number of times you tried on clothes:" + times);
        System.out.print("Do you want to try on your clothes again? please input true or false: ");
        tryAagin = new Scanner(System.in).nextBoolean();

        // The equivalent while loop
        while(tryAagin == true){
            times++;
            System.out.println("The number of times you tried on clothes:" + times);
            System.out.print("Do you want to try on your clothes again? please input true or false: ");
            tryAagin = new Scanner(System.in).nextBoolean();
        }
    }
}
```
Outputs:
``` java
The number of times you tried on clothes:1
Do you want to try on your clothes again? please input true or false: true
The number of times you tried on clothes:2
Do you want to try on your clothes again? please input true or false: false
```
#### 1.2.3. The equivalent for loop
Codes:
``` java
package discussion_assignment_1;

/**
 * Calculate the product of positive integers 1 to 10
 */
public class ForLoop {
    public static void main(String[] args) {
        //Initialization
        int product = 1;

        //The equivalent for loop
        for (int i = 1; i < 11; i ++){
            product *= i;
        }

        System.out.printf("The product of positive integers 1 to 10 is: %d ", product);
    }
}
```
Outputs:
``` java
The product of positive integers 1 to 10 is: 3628800
```

### 1.3. Examples for a for loop, the equivalent while loop and do-while loop
#### 1.3.1. A for loop
Codes:
``` java
package discussion_assignment_3;

/**
 * Output all uppercase letters in the string.
 */
public class ForLoop {
    public static void main(String[] args) {
        //initialization
        String s = "Jane is A Very Amazing studnet";
        String uppercaseLetters = "";

        //for loop
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') {
                uppercaseLetters += s.charAt(i);
            }
        }

        System.out.println(uppercaseLetters);
    }
}
```
Outputs:
``` java
JAVA
```
#### 1.3.2. The equivalent while loop:
Codes:
``` java
package discussion_assignment_3;

/**
 * Output all uppercase letters in the string.
 */
public class WhileLoop {
    public static void main(String[] args) {
        //Initialization
        String s = "Jane is A Very Amazing studnet";
        String uppercaseLetters = "";
        int i = 0;

        //The equivalent while loop
        while (i < s.length()) {
            if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') {
                uppercaseLetters += s.charAt(i);
            }
            i++;
        }

        System.out.println(uppercaseLetters);
    }
}
```
Outputs:
``` java
JAVA
```
#### 1.3.3. The equivalent do-while loop
Codes:
``` java
package discussion_assignment_3;

/**
 * Output all uppercase letters in the string.
 */
public class DoWhileLoop {
    public static void main(String[] args) {
        //Initialization
        String s = "Jane is A Very Amazing studnet";
        String uppercaseLetters = "";
        int i = 0;

        //The equivalent do-while loop
        do{
            if (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') {
                uppercaseLetters += s.charAt(i);
            }
            i++;
        }while(i < s.length());

        System.out.println(uppercaseLetters);
    }
}
```
Outputs:
``` java
JAVA
```


## 2. Advantages and Disadvantages
According to Downey, "It's quite possible that in real programs, for loops actually outnumber while loops" (2019, p. 92). In other words, for loop is more commonly used than while loop. This is because for loop has some advantages that other loop does not own: "The initialization, continuation condition, and updating have all been combined in the first line of the for loop. This keeps everything involved in the "control" of the loop in one place, which helps make the loop easier to read and understand" (Downey, 2019, p. 92). 

Conversely, the while loop and do-while loop do not put initialization, continuation condition, and updating in the same row, so they are not as easy to read and understand as for loop.

For instance, in the example of calculating the product of positive integers 1 to 10, the for loop put "int i = 1; i < 11; i ++" in one line, but the while loop and do while loop put them at different places, respectively. Hence, to some extent, the while loop and do-while loop are not as concise as the for loop.

Regrading the do-while loop, "since the condition is not tested until the end of the loop, its body is always executed at least once" (Downey, 2019, p. 89). Therefore, sometimes it is convenient to use a do-while loop for tasks that must be done at least once.

For instance, when buying clothes, we usually try at least one time before we decide to buy them. Hence, it is more suitable to use a do-while loop instead of for loop or while loop in this case. As we can see, in the example of trying on clothes some times before buying them, the codes using the do-while loop are much less than the codes using the while loop. Therefore, in some situations, the do-while loop is more advantageous.


Word count: 1243



## References
1.Downey, A. (2015). Think Python. Green Tea Press.
https://greenteapress.com/thinkpython2/thinkpython2.pdf

2.Eck, D. J. (2019). Introduction to Programming Using Java. 
http://math.hws.edu/javanotes




​	

---

<center>This is the ending, thanks for reading.</center>

---