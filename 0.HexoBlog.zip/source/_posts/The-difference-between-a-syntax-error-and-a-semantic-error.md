---
title: The difference between a syntax error and a semantic error
tags:
  - Java
  - CS1102
  - CS1102 Discussion Assignment
  - Private
categories: Java
description: "CS1102 discussion assignment unit 1. Here's something encrypted, password is required to continue reading."
theme: up
password: 'Private@UoPeople'
date: 2022-01-09 09:41:29
---
## Questions
The Java compiler does not always provide a default constructor. It only provides a default constructor when the programmer does not provide any constructor in the class. This blog will first introduce the different types of constructors and then prove that the compiler does not always provide a default constructor.
<!--more-->

## 1. Explanation
### 1.1. Syntax
**Syntax** is “the rules that govern the structure of a program” (Downey, 2015, p. 7). Specifically, “it specifies the basic vocabulary of the language and how programs can be constructed using things like loops, branches, and subroutines” (Eck, 2019, p. 19).

### 1.2. Semantics
**Semantics** is “the meaning of a program” (Downey, 2015, p. 15). In other words, “a semantically correct program is one that does what you want it to” (Eck, 2019, p. 19).

### 1.3. Syntax Error
The **syntax error** is “an error in a program that makes it impossible to parse (and therefore impossible to interpret)” (Downey, 2015, p. 15).

### 1.4. Semantic Error
The **semantic error** is “an error in a program that makes it do something other than what the programmer intended” (Downey, 2015, p. 15). That is to say, although the program can be parsed and interpreted, the outputs or results are not what the programmers want.

## 2. Examples
### 2.1. Example of syntax error
Codes:
``` java
package discussion_assignment;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println(Hello World);
    }
}
```
Outputs:
``` java
F:\ Programs\week1\src\hello_world\HelloWorld.java:5:33
java: ')' expected
```
Explanation:
In the standard output statement `System.out.println(Hello World);`, the strings `Hello World` lacks double quotation marks, which leads to a parsing error and the interpreter reports it. Therefore, this is an example of syntax error.

### 2.2. Example of semantic error
Codes:
``` java
package discussion_assignment;

import java.util.Scanner;

public class CalculateArea {
    public static void main(String[] args) {
        Scanner stdin = new Scanner(System.in); //Create the Scanner

        System.out.print("Enter the length of the rectangle: ");
        double length = stdin.nextDouble();
        System.out.print("Enter the width of the rectangle: ");
        double width = stdin.nextDouble();

        double area = (length + width) * 2; // Calculate the area of the rectangle

        System.out.printf("The area of the rectangle is: %1.2f", area);
    }
}
```
Outputs:
``` java
Enter the length of the rectangle: 2.00
Enter the width of the rectangle: 3.00
The area of the rectangle is: 10.00
```
Explanation:
The purpose of the program above is to calculate the rectangle's area. As we can see, the program was parsed successfully, and the interpreter returned the results. However, in the program, the statement calculated the circumference instead and assigned it to the variable area. As a result, when I input the length 2.00 and the width 3.00, the result was the circumference 10.00 instead of the area 6.00. Therefore, the program failed to achieve the programmer's intention, which is an example of semantic error.  



Word count: 399



## References
1.Downey, A. (2015). Think Python. Green Tea Press.
https://greenteapress.com/thinkpython2/thinkpython2.pdf

2.Eck, D. J. (2019). Introduction to Programming Using Java. 
http://math.hws.edu/javanotes




​	

---

<center>This is the ending, thanks for reading.</center>

---