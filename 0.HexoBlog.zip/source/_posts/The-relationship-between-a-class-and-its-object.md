---
title: The relationship between a class and its object
tags:
  - Java
  - CS1102
  - CS1102 Discussion Assignment
  - Private
categories: Java
description: "CS1102 discussion assignment unit 4. Here's something encrypted, password is required to continue reading."
theme: up
password: "Private@UoPeople"
date: 2022-01-23 09:46:06
---
## Questions
Give an example of a class and an example of an object. Describe what a class is, what an object is, and how they are related. Use your examples to illustrate the descriptions.
<!--more-->

## 1. Descriptions
**Class**: A class is like a factory or a blueprint, and we can use it to define variables and create objects. To declare a class, we start with public, then class, then the name of the class, finally, the body of the class in {}. In the body of the class, it can include static member variables, instance variables, static methods, instance methods, and constructors (Seiter & Palmer, 2020).

**Object**:  An object is an instance of a class. In other words, an object is a collection of data and methods manipulating these data (Downey, 2019). More specifically, objects are created by the non-static portions of classes, and they have attributes and behaviors. The Attributes and behaviors correspond to instance variables and instance methods in a class, respectively. The instance variables store the data for an object, and the instance methods allow objects to manipulate these data (Seiter & Palmer, 2020).

**Relation**: The non-static portions of classes are used to create objects. The object's attributes correspond to the class's instance variables, and the object's behaviors correspond to the class's instance methods. A class can have many objects with the same structure (Eck, 2019).

## 2. Examples
**Codes**:

``` java
package discussion_assignment;

public class Fruits {
    // instance variables
    private String name;
    private String color;

    // constructor
    public Fruits(String initName, String initColor) {
        name = initName;
        color = initColor;
    }

    // instance method
    public void print() {
        System.out.printf("name: %s, color: %s\n", name, color);
    }

    // main method
    public static void main(String[] args) {
        // call the constructor to create fruit objects
        Fruits fruit1 = new Fruits("banana", "yellow");
        Fruits fruit2 = new Fruits("apple", "red");
        Fruits fruit3 = new Fruits("peach", "pink");

        //print the fruits
        fruit1.print();
        fruit2.print();
        fruit3.print();
    }
}
```
**Outputs**:
``` java
name: banana, color: yellow
name: apple, color: red
name: peach, color: pink
```
**Explanation**:
In the above example, I created a class Fruit. It has two instance variables: name and color. Besides, I rewrote the constructor. This constructor has two parameters: initName and initColor. Hence, I can initialize the instance variables name and color when I use this constructor to create objects. In addition, I defined an instance method print(), which is used to print the fruit information.

To create new objects and test instance methods, I defined a main() method in the class. In the main(), I created three different objects: fruit1, fruit2, and fruit3. Then, I used the three objets to call the print() method respectively to output the fruit information owned by the different objects.

As we can see, the fruit class is a factory, which has instance variables and instance methods. And the fruit objects are created by the Fruit class. Different fruit objects store specific fruit data and methods to print these data. In addition, one Fruit class can create multiple objects, and these objects have the same structure.



Word count: 466





## References
1.Downey, A.B. & Mayfield, C. (2019). Think Java (2nd ed.). Green Tea Press. 
https://open.umn.edu/opentextbooks/formats/331

2.Eck, D. J. (2019). Introduction to Programming Using Java. 
http://math.hws.edu/javanotes




​	

---

<center>This is the ending, thanks for reading.</center>

---