---
title: Is a default constructor always provided by the Java compiler?
date: 2021-12-30 14:44:19
tags:  [Java, CS1102]
categories: Java
---
## Introduction
The Java compiler does not always provide a default constructor. It only provides a default constructor when the programmer does not provide any constructor in the class. This blog will first introduce the different types of constructors and then prove that the compiler does not always provide a default constructor.
<!--more-->

## 1. Types of Constructors
Generally speaking, there are three types of constructors: **the default constructor, no-parameter constructor, and constructor with parameters**.

**Default constructor**: A constructor without parameters, which is created by the Java compiler during the compiling phase.

**No-parameter constructor**: A constructor without parameters, which is created by the programmers when they write the source code(.java file).

**Constructor with parameters**: A constructor that have some parameters, which is created by the programmers when they write the source code(.java file).

## 2. The Proof Process
### 2.1. The process of compiling and interpreting a Java program
![process](https://github.com/zhiyaohe/blog-images/blob/main/2021-12-30-Is%20a%20default%20constructor%20always%20provided%20by%20the%20Java%20compiler/1.The%20process%20of%20compiling%20and%20interpreting%20a%20Java%20program.png?raw=true)
<center>The process of compiling and interpreting a Java program (Downey, 2019, p. 9)</center>

The process of compiling and interpreting a Java source code is: first, a programmer writes a .java file; second, the compiler will compile it to a .class file; finally, the interpreter(JVM, Java Virtue Machine) will interpret it.

### 2.2. The proof steps
The Java compiler would add the default constructor when compiling the .java file into the .class file. Hence, the .class file should have a constructor created by the compiler if it did provide. Therefore, we can check the .class file to see whether the compiler would give a default constructor if the programmers do not offer any constructor. For the .class file, we can use the [javap](https://docs.oracle.com/javase/7/docs/technotes/tools/windows/javap.html) command to disassemble it, and the outputs will show us what it includes. Simply, the process is: 
<center>Compiling the .java file –> using javap to disassemble the .class file -> ckeck the outputs</center>

Next, I will use two programs to prove: a .java file without any constructor given by the programmer and a .java file with a constructor provided by the programmer.

### 2.3. The proof examples
#### 2.3.1. Example of a .java file without constructor given by the programmer
The following [DocFooter.java](https://docs.oracle.com/javase/7/docs/technotes/tools/windows/javap.html) is the source code without any constructor declaring by the programmer:
``` java
import java.awt.*;
import java.applet.*;

public class DocFooter extends Applet {
    String date;
    String email;

    public void init() {
        resize(500, 100);
        date = getParameter("LAST_UPDATED");
        email = getParameter("EMAIL");
    }

    public void paint(Graphics g) {
        g.drawString(date + " by ", 100, 15);
        g.drawString(email, 290, 15);
    }
}
```
<center>DocFooter.java without any constructor declaring by the programmer  (Oracle, n.d.)</center>

Now, we can use the java command to compile the DocFooter.java, and the compiler will generate a .class file, like this: 

``` java
C:\Users\AI\Desktop>java DocFooter.java
```

After getting the .class file, we can use the [javap](https://docs.oracle.com/javase/7/docs/technotes/tools/windows/javap.html) command to disassemble it. And the outputs will show us what it includes:
``` java
C:\Users\AI\Desktop>javap DocFooter.class
Compiled from "DocFooter.java"
public class DocFooter extends java.applet.Applet {
    java.lang.String date;
    java.lang.String email;
    public DocFooter();
    public void init();
    public void paint(java.awt.Graphics);
}
```
As we can see, there are no constructors in the DocFooter.java file, but in the disassemble outputs, there is a constructor: DocFooter(), which illustrates that the compiler would provide a default constructor if the programmer did not offer constructors to the class.

#### 2.3.2. Example of a .java file with a constructor provided by the programmer
Now, I will add a constructor in the above DocFooter.java to see whether the compiler will add a default constructor. The following DocFooter.java is the source code with  a  constructor declaring by the programmer:
``` java
import java.awt.*;
import java.applet.*;

public class DocFooter extends Applet {
    String date;
    String email;
 
    // the constructor provided by the programmer
    DocFooter(String date, String email) {
        this.date = date;
        this.email = email;
    }

    public void init() {
        resize(500, 100);
        date = getParameter("LAST_UPDATED");
        email = getParameter("EMAIL");
    }

    public void paint(Graphics g) {
        g.drawString(date + " by ", 100, 15);
        g.drawString(email, 290, 15);
    }
}
```
<center>DocFooter.java with a constructor declaring by the programmer</center>

Now, we can use the java command to compile the DocFooter.java, and the compiler will generate a .class file, like this: 

``` java
C:\Users\AI\Desktop>java DocFooter.java
```

After getting the .class file, we can use the [javap](https://docs.oracle.com/javase/7/docs/technotes/tools/windows/javap.html) command to disassemble it. And the outputs will show us what it includes:
``` java
C:\Users\AI\Desktop>javap DocFooter.class
Compiled from "DocFooter.java"
public class DocFooter extends java.applet.Applet {
    java.lang.String date;
    java.lang.String email;
    DocFooter(java.lang.String, java.lang.String);
    public void init();
    public void paint(java.awt.Graphics);
}
```
As we can see, there is no default constructor in the outputs, and it only has the constructor: DocFooter(java.lang.String, java.lang.String), which the programmer provides. Hence, the compiler does not provide a default constructor if the programmer provides constructors in the source codes.


## 3. In Conclusion
Based on the above examples and at a compiler level, we prove that the Java compiler does not always provide a default constructor. It only provides a default constructor when the programmer does not provide any constructor in the souce code.


## References
1.Downey, A.B., & Mayfield, C. (2019). *Think Java (2nd ed.)*. Green Tea Press. 
https://open.umn.edu/opentextbooks/formats/331

2.ORACLE. (n.d.). Providing Constructors for Your Classes.
https://docs.oracle.com/javase/tutorial/java/javaOO/constructors.html

3.ORACLE. (n.d.). javap - The Java Class File Disassembler.
https://docs.oracle.com/javase/7/docs/technotes/tools/windows/javap.html  



​	

---

<center>This is the ending, thanks for reading.</center>

---