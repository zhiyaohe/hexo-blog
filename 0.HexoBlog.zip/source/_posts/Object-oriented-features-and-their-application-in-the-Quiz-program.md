---
title: Object-oriented features and their application in the Quiz program
tags:
  - Java
  - CS1102
  - CS1102 Discussion Assignment
  - Private
categories: Java
description: "CS1102 discussion assignment unit 8. Here's something encrypted, password is required to continue reading."
theme: up
password: "Private@UoPeople"
date: 2022-01-23 19:11:42
---
## Questions
Describe how you would develop object-oriented features of Java for the Quiz program developed in the Programming Assignments. In particular, describe how the program could use each of the following: class variables, instance variables, inheritance, polymorphism, abstract classes, "this", "super", interfaces, and event listeners.face
<!--more-->

## 1. class variables
**Definition**: Class variables are also called static variables. They are modified by the static modifier, belong to the class rather than objects, and can be called directly by the class name.

**Application**: In the Question.java file, I define two class variables: nQuestions and nCorrect, modified by the modifier static and used to count the total questions and the correct questions, respectively.

## 2. instance variables
**Definition**: Instance variables are non-static variables. They have no static modifier, belong to the object rather than class.

**Application**: In the Question.java file, I define two instance variables: question and correctAnswer. The difference between instance and class variables is that instance variables do not have the modifier static and belong to the object instead of the class.

## 3. inheritance
**Definition**: Inheritance means a subclass extends one superclass. The subclass will have all the methods and variables in the superclass. Besides, one subclass can only extend one superclass.

**Application**: The TrueFalseQuestion class and MultipleChoiceQuestion class both extend the Question class in the Quiz program. Hence, they will have all the methods and instance variables in the superclass Question. For example, the subclass TrueFalseQuestion can use the correctAnswer variable and initQuestionDialog() method, which inherit from the superclass Question.

## 4. polymorphism
**Definition**: Polymorphism means the method called at run-time depends on the actual (run-time) type instead of the declared (compile-time) type ((Seiter & Palmer, 2020). For example, the class Student extends the class People and overrides the printInfo() method. People s = new Students(); s. printInfo() will call the Student’s printInfo() method instead of the People’s. Besides, we should note that variables are not polymorphic. For instance, s.age will call the People's variable age instead of the Student's.

**Application**: The QuestionDialog class implements the ActionListener interface and overrides its actionPerformed() method. Hence, when a button is clicked, the QuestionDialog's actionPerformed() method will be called instead of the ActionListener's. This is polymorphism.

## 5. abstract classes
**Definition**: The abstract class is a class with the modifier abstract, it may have or not have abstract methods, and it can also include non-abstract methods.  We can use a subclass to extend the abstract class but note that we cannot create objects using an abstract class directly.

**Application**: The class Question is an abstract class, which has a modifier abstract. And I withdraw some common features from its subclass MultipleChoiceQuestion and TrueFalseQuestion, including some variables (like correctAnswer) and some methods (like initQuestionDialog()), so the codes will be more concise.

## 6. "this"
**Definition**: The keyword this is a reference to the current object. We can use it to call other constructors (this() or this(arguments)) and distinguish an instance variable and a local parameter (this.variableName) in the same class (Seiter & Palmer, 2020).

**Application**: In the Question class's constructor, I use the statement this.question = new QuestionDialog() to initialize the QuestionDialog type variable question. "this" is a reference to the current object.

## 7. "super"
**Definition**: The keyword super is a reference to the superclass object. We can use it to call the superclass constructors (super() or super(arguments)) and superclass instance methods(super.methodName) (Seiter & Palmer, 2020).

**Application**: In the TrueFalseQuestion class's constructor, I use super(question) to call its superclass Question's constructor. In the MultipleChoiceQuestion class's constructor, I use super(query) to call its superclass Question's constructor.

## 8. interfaces
**Definition**: An interface contains methods declaration without their implementation. To declare an interface, we need to use the keyword interface; to implement an interface, we need to use the keyword implements and override all the methods in the subclass.

**Application**:  I use the QuestionDialog class to implement the ActionListener interface. Hence, I can create a listener to listen to the button click events, and handle it.


## 9. event listeners
**Definition**: "An event listener is an instance of a class that implements a listener
interface" ( Horstmann, 2019, p. 800).

**Application**: In the Question class's construtor Question(String question), I use the statement this.question = new QuestionDialog() to initialize the variable question. The new QuestionDialog() will create an event listener object because the QuestionDialog class implements the ActionListener interface.




Word count: 679


## Appendix
**The Quiz program with button-based dialog boxes specialized for multiplechoice and true-false questions**:
``` java
public class Quiz {

    public static void main(String[] args) {
        // Define the 1st multiple-choice question and give its correct answer
        Question question = new MultipleChoiceQuestion("What is the product of 2 times 3?", "0", "2", "4", "6",
                "I do not know.", "d");
        // Test the "check" method
        question.check();

        // Define the 2sd multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("How many 2 are there in 10?", "5", "2", "3", "10", "I have no idea.",
                "a");
        // Test the "check" method
        question.check();

        // Define the 3rd multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is the sum of 2 and 4?", "4", "5", "6", "7", "I have no idea.",
                "c");
        // Test the "check" method
        question.check();

        // Define the 4th multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is 10 minus 5?", "0", "5", "6", "8", "I have no idea.", "b");
        // Test the "check" method
        question.check();

        // Define the 5th multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is 100 divided by 25?", "3", "5", "4", "2", "I have no idea.", "c");
        // Test the "check" method
        question.check();

        // Define the 1th true/false question and give its correct answer
        question = new TrueFalseQuestion("2 + 3 = 6", "false");
        // Test the "check" method
        question.check();

        // Define the 2th true/false question and give its correct answer
        question = new TrueFalseQuestion("10 < 5", "false");
        // Test the "check" method
        question.check();

        // Define the 3th true/false question and give its correct answer
        question = new TrueFalseQuestion("9 - 4 = 3", "false");
        // Test the "check" method
        question.check();

        // Define the 4th true/false question and give its correct answer
        question = new TrueFalseQuestion("2 > 3", " false");
        // Test the "check" method
        question.check();

        // Define the 5th true/false question and give its correct answer
        question = new TrueFalseQuestion("The remainder of 10 divided by 3 is 1.", "true");
        // Test the "check" method
        question.check();

        // The score for the quiz
        Question.showResults();
    }
}
```
``` java
import java.awt.event.*;
import javax.swing.*;

public class QuestionDialog extends JDialog implements ActionListener {
    String answer;

    @Override
    public void actionPerformed(ActionEvent e) {
        //set the instance variable answer
        answer = e.getActionCommand();
        //calls the inherited dispose() method
        dispose();
    }
}
```
``` java
import java.awt.*;
import javax.swing.*;

public abstract class Question {
    // class variables
    static int nQuestions = 0;
    static int nCorrect = 0;

    // instance variables
    QuestionDialog question;
    String correctAnswer;

    //create a Question constructor
    Question(String question) {
        // initialize the instance variable question
        this.question = new QuestionDialog();
        // gives it a single-column grid layout
        this.question.setLayout(new GridLayout(0, 1));
        // add the question text to its content
        this.question.add(new JLabel("            " + question + "            ", JLabel.CENTER));
    }

    void initQuestionDialog() {
        // makes instance variable question modal
        this.question.setModal(true);
        // sets its size with pack()
        this.question.pack();
        // position it in the center of the screen
        this.question.setLocationRelativeTo(null);
    }

    // declare an ask()
    String ask() {
        question.setVisible(true);
        return question.answer;
    }

    // instance method check()
    void check() {
        String answer = ask();
        nQuestions++;

        if (answer.equals(correctAnswer)) {
            nCorrect++;
            JOptionPane.showMessageDialog(null, "Correct!");
        } else {
            JOptionPane.showMessageDialog(null, "Incorrect. The correct answer is " + correctAnswer + ".");
        }
    }

    // class method showResults()
    static void showResults() {
        JOptionPane.showMessageDialog(null, nCorrect + " correct out of " + nQuestions + " questions");
    }

}
```
``` java
import javax.swing.JOptionPane;
import javax.swing.*;

public class TrueFalseQuestion extends Question {

    // add a constructor
    public TrueFalseQuestion(String question, String answer) {
        // Initialize question
        super(question); // call the superclass Question's constructor.

        // calls "addButton" to add "TRUE" and "FALSE" buttons to a panel
        JPanel buttons = new JPanel();
        addButton(buttons, "TRUE");
        addButton(buttons, "FALSE");
        // adds that panel to the instance variable "question"
        this.question.add(buttons);

        // calls the initQuestionDialog()
        initQuestionDialog();

        // initialize correctAnswer
        answer = answer.toUpperCase();
        if (answer.equals("T") || answer.equals("TRUE") ||
                answer.equals("Y") || answer.equals("YES")) correctAnswer = "TRUE";
        if (answer.equals("F") || answer.equals("FALSE") ||
                answer.equals("N") || answer.equals("NO")) correctAnswer = "FALSE";
    }

    void addButton(JPanel buttons, String label) {
        // construct a button using its String parameter label
        JButton button = new JButton(label);
        // adds the instance variable question as a listener for that button
        button.addActionListener(question);
        // add the button to its JPanel parameter buttons
        buttons.add(button);
    }
}
```
``` java
import java.awt.*;
import javax.swing.*;

public class MultipleChoiceQuestion extends Question {

    // add a constructor
    public MultipleChoiceQuestion(String query, String a, String b, String c, String d, String e, String answer) {
        // calls its superclass constructor with its first parameter query
        super(query);

        // calls addChoice() using its next five parameters
        addChoice("A", a);
        addChoice("B", b);
        addChoice("C", c);
        addChoice("D", d);
        addChoice("E", e);

        // calls initQuestionDialog()
        initQuestionDialog();

        // initialize correctAnswer
        correctAnswer = answer.toUpperCase();
    }

    // declare the addChoice()
    void addChoice(String name, String label) {
        //  creates a panel with a border layout
        JPanel choice = new JPanel(new BorderLayout());
        // creates a button using its first String parameter name
        JButton button = new JButton(name);
        // adds the instance variable "question" as a listener for that button
        button.addActionListener(question);
        // adds the button to the left side of the panel
        choice.add(button, BorderLayout.WEST);
        // adds a label to the center of the panel
        choice.add(new JLabel("        " + label + "        ", JLabel.LEFT), BorderLayout.CENTER);
        //  add the panel to the instance variable "question"
        question.add(choice);
    }
}
```

**The Quiz program with text-based dialog boxes specialized for multiplechoice and true-false questions**:
``` java
public class Quiz {

    public static void main(String[] args) {
        // Define the 1st multiple-choice question and give its correct answer
        Question question = new MultipleChoiceQuestion("What is the product of 2 times 3?", "0", "2", "4",
                "6", "I do not know.", "d");
        // Test the "check" method
        question.check();


        // Define the 2sd multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("How many 2 are there in 10?", "5", "2", "3", "10", "I have no idea.",
                "a");
        // Test the "check" method
        question.check();


        // Define the 3rd multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is the sum of 2 and 4?", "4", "5", "6", "7", "I have no idea.",
                "c");
        // Test the "check" method
        question.check();


        // Define the 4th multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is 10 minus 5?", "0", "5", "6", "8", "I have no idea.", "b");
        // Test the "check" method
        question.check();


        // Define the 5th multiple-choice question and give its correct answer
        question = new MultipleChoiceQuestion("What is 100 divided by 25?", "3", "5", "4", "2", "I have no idea.", "c");
        // Test the "check" method
        question.check();


        // Define the 1th true/false question and give its correct answer
        question = new TrueFalseQuestion("2 + 3 = 6", "false");
        // Test the "check" method
        question.check();


        // Define the 2th true/false question and give its correct answer
        question = new TrueFalseQuestion("10 < 5", "false");
        // Test the "check" method
        question.check();


        // Define the 3th true/false question and give its correct answer
        question = new TrueFalseQuestion("9 - 4 = 3", "false");
        // Test the "check" method
        question.check();


        // Define the 4th true/false question and give its correct answer
        question = new TrueFalseQuestion("2 > 3", " false");
        // Test the "check" method
        question.check();


        // Define the 5th true/false question and give its correct answer
        question = new TrueFalseQuestion("The remainder of 10 divided by 3 is 1.", "true");
        // Test the "check" method
        question.check();


        // The score for the quiz
        MultipleChoiceQuestion.showResults();
    }
}
```
``` java
import javax.swing.JOptionPane;

public abstract class Question {
    // class variables
    static int nQuestions = 0;
    static int nCorrect = 0;

    // instance variables
    String question;
    String correctAnswer;

    // declare an abstract ask()
    abstract String ask();

    // instance method check()
    void check() {
        String answer = ask();
        nQuestions++;

        if (answer.equals(correctAnswer)) {
            nCorrect++;
            JOptionPane.showMessageDialog(null, "Correct!");
        } else {
            JOptionPane.showMessageDialog(null, "Incorrect. The correct answer is " + correctAnswer + ".");
        }
    }

    // class method showResults()
    static void showResults() {
        JOptionPane.showMessageDialog(null, nCorrect + " correct out of " + nQuestions + " questions");
    }
}
```
``` java
import javax.swing.JOptionPane;

public class MultipleChoiceQuestion extends Question {

    // add a constructor
    public MultipleChoiceQuestion(String query, String a, String b, String c, String d, String e, String answer) {
        // Initialize question
        question = query + "\n";
        question += "A. " + a + "\n";
        question += "B. " + b + "\n";
        question += "C. " + c + "\n";
        question += "D. " + d + "\n";
        question += "E. " + e + "\n";

        // Initialize correctAnswer
        correctAnswer = answer.toUpperCase();
    }

    // override the method ask()
    String ask() {
        while (true) {
            String answer = JOptionPane.showInputDialog(question);
            answer = answer.toUpperCase();

            if (answer.equals("A") || answer.equals("B") || answer.equals("C") || answer.equals("D")
                    || answer.equals("E")) {
                return answer;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid answer. Please enter A, B, C, D, or E.");
            }
        }
    }
}
```
``` java
import javax.swing.JOptionPane;

public class TrueFalseQuestion extends Question {

    // add a constructor
    public TrueFalseQuestion(String question, String answer) {
        // Initialize question
        this.question = "TRUE or FALSE: " + question;

        // Initialize correctAnswer
        correctAnswer = answer.toUpperCase();
    }

    @Override
    String ask() {
        while (true) {
            String answer = JOptionPane.showInputDialog(question);
            answer = answer.toUpperCase();

            if (answer.equals("F") || answer.equals("FALSE") || answer.equals("N") || answer.equals("NO")) {
                return "FALSE";
            } else if (answer.equals("T") || answer.equals("TRUE") || answer.equals("Y") || answer.equals("YES")) {
                return "TRUE";
            } else {
                JOptionPane.showMessageDialog(null, "Invalid answer. Please enter TRUE or FALSE.");
            }
        }
    }
}
```




## References
1.Seiter, L. & Palmer, D. (2020). Introduction to Programming with Java (8th ed.).
https://runestone.academy/runestone/books/published/csjava/index.html


2.Horstmann, C. S. (2019). Core Java Volume I–Fundamentals (11th ed.). Pearson.



​	

---

<center>This is the ending, thanks for reading.</center>

---